export default {
	testEnvironment: "node",
}
